#ifndef TASKS_H
#define TASKS_H

extern void Task1(void);
extern void Task2(void);
extern void Task3(void);

#endif // TASKS_H