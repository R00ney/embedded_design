#ifndef PROFILE_H
#define PROFILE_H
extern void Init_Profiling(void);

extern void Disable_Profiling(void);
extern void Enable_Profiling(void);
extern void Print_Results(void);
#endif
