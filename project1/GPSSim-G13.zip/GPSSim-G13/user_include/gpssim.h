#ifndef GPSSIM_H
#define GPSSIM_H


#define NUM_STEPS 100
#define MSG_PERIOD 2000


extern void sim_motion(void);


#endif // GPSSIM_H
