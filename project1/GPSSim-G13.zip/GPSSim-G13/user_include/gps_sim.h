#ifndef GPS_SIM_H
#define GPS_SIM_H


#define NUM_STEPS 100
#define MSG_PERIOD 2000


extern void sim_motion(void);


#endif // GPS_SIM_H

